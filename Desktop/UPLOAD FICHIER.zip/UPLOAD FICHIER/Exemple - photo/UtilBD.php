<?php
  // Fonctions et d�clarations pour l'acc�s � MySQL
  require_once ("Connect.php");
  require_once ("Connexion.php");
  require_once ("ExecRequete.php");
?>