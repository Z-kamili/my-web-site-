<?php
  //
  // Fichier contenant les definitions de constantes
  // pour la connexion � MySQL

  #define ('NOM',"adminFilms");
  define ('NOM',"root");
  #define ('PASSE', "mdpAdmin");
    define ('PASSE', "");
  define ('SERVEUR', "localhost");
  define ('BASE', "films");
?>
